// The comment is part of code which is not actual code but we use it for our understanding like text what the code is doing

// use for in line comment

var name="java script" //this is comment

/* you can write as many things as you want
In multiple line *
write as many lines as you want then end with */