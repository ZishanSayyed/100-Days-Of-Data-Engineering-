// Import the capitalString function
import { capitalString } from "./22.2export";

// Use the imported function
const cap = capitalString("hi");
console.log(cap);