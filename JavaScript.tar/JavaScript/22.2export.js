export const capitalString = (str) => str.toUpperCase();
