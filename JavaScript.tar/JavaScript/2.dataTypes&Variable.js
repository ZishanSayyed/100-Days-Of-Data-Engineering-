/*
7 types of data types 
Undefine
Null: noting 
Boolean: true/ false 
String: character type variables
Symbol: immutable permitted value which is unique 
Number: Number 
Object:key-value pairs 

*/


/* Variable: its like a box we assign values to Variable: its like a box we assign values to 3 ways to define Variables  */

var MyName="Zishan"
console.log(MyName);

let surname="Sayyed";
console.log(surname);

const piValue=3.14
console.log(piValue);


//var and let create variables that can be reassigned another value.
//const creates "constant" variables that cannot be reassigned another value.


var a;   //we use var to declare variable  //before any assigned to this variable is  fall under  data type undefine

a=7 // here we use = to assign values to our variable 

var b=5; // we can do both simultaneously ; is use to show end of the line is not monitory but best practices 

console.log(a);  //is like a print fun to see output

/* Java script is case-sensitive */


/* Camel Case is writing style type use for better writing style of your code */

var myname="zishan" //normal style 
var myName="zishan" // camel case
