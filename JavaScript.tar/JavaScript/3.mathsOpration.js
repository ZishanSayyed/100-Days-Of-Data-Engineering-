var add=1 +1;
var add;
add=5;
add=add+1;
console.log(add);

// another way 
var myVar=5;
myVar++;  //increment by 1
console.log(myVar);

// Same can be done for +,×,/ use respective symbols do to do so


// To fine reminder % is use
var findReminder=11%2;
console.log(findReminder); // Reminder operations done to find if number is even or odd


// Sort cuts 
//normal way
var a=5;
a=a+10;
console.log(a);

// Shortcut
var a=5;
a+=10;


//same thing can be done for -,×,/,%